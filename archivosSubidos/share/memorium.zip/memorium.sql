-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.6.21 - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura de base de datos para memorium
CREATE DATABASE IF NOT EXISTS `memorium` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `memorium`;


-- Volcando estructura para tabla memorium.historyvotes
CREATE TABLE IF NOT EXISTS `historyvotes` (
  `idHistoryVotes` int(255) NOT NULL AUTO_INCREMENT,
  `emailUser` varchar(100) NOT NULL,
  `idTheme` int(255) NOT NULL,
  PRIMARY KEY (`idHistoryVotes`),
  KEY `idUser` (`emailUser`),
  KEY `idTheme` (`idTheme`),
  CONSTRAINT `FK_historyVotes_themes` FOREIGN KEY (`idTheme`) REFERENCES `themes` (`idTheme`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_historyvotes_users` FOREIGN KEY (`emailUser`) REFERENCES `users` (`emailUser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla memorium.historyvotes: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `historyvotes` DISABLE KEYS */;
INSERT INTO `historyvotes` (`idHistoryVotes`, `emailUser`, `idTheme`) VALUES
	(40, 'davidhnmunoz@gmail.com', 49),
	(41, 'davidhnmunoz@gmail.com', 48),
	(49, 'davidhnmunoz@gmail.com', 47),
	(50, 'davidhnmunoz@gmail.com', 53);
/*!40000 ALTER TABLE `historyvotes` ENABLE KEYS */;


-- Volcando estructura para tabla memorium.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `idMessage` int(255) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) NOT NULL DEFAULT '0',
  `emiter` varchar(100) NOT NULL DEFAULT '0',
  `receiver` varchar(100) NOT NULL DEFAULT '0',
  `datemessage` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idMessage`),
  KEY `emiter` (`emiter`),
  KEY `receiver` (`receiver`),
  CONSTRAINT `FK_messages_users` FOREIGN KEY (`emiter`) REFERENCES `users` (`emailUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_messages_users_2` FOREIGN KEY (`receiver`) REFERENCES `users` (`emailUser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla memorium.messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;


-- Volcando estructura para tabla memorium.reminder
CREATE TABLE IF NOT EXISTS `reminder` (
  `idReminder` int(11) NOT NULL AUTO_INCREMENT,
  `emailUser` varchar(100) NOT NULL DEFAULT '0',
  `titleReminder` varchar(20) NOT NULL DEFAULT '0',
  `descriptionReminder` varchar(255) NOT NULL DEFAULT '0',
  `dateReminder` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `path1` varchar(255) DEFAULT '0000-00-00 00:00:00',
  `path2` varchar(255) DEFAULT '0000-00-00 00:00:00',
  `path3` varchar(255) DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`idReminder`),
  KEY `idUser` (`emailUser`),
  CONSTRAINT `FK_reminder_users` FOREIGN KEY (`emailUser`) REFERENCES `users` (`emailUser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla memorium.reminder: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `reminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder` ENABLE KEYS */;


-- Volcando estructura para tabla memorium.storage
CREATE TABLE IF NOT EXISTS `storage` (
  `idStorage` int(255) NOT NULL AUTO_INCREMENT,
  `storagepath` varchar(50) NOT NULL DEFAULT '0',
  `emailUser` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idStorage`),
  KEY `idUser` (`emailUser`),
  CONSTRAINT `FK_storage_users` FOREIGN KEY (`emailUser`) REFERENCES `users` (`emailUser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla memorium.storage: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `storage` ENABLE KEYS */;


-- Volcando estructura para tabla memorium.themes
CREATE TABLE IF NOT EXISTS `themes` (
  `idTheme` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `emailUser` varchar(100) NOT NULL DEFAULT '0',
  `datatheme` datetime DEFAULT '0000-00-00 00:00:00',
  `points` int(11) DEFAULT '0',
  `votes` int(11) DEFAULT '0',
  PRIMARY KEY (`idTheme`),
  KEY `idUser` (`emailUser`),
  CONSTRAINT `FK_themes_users` FOREIGN KEY (`emailUser`) REFERENCES `users` (`emailUser`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla memorium.themes: ~8 rows (aproximadamente)
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` (`idTheme`, `title`, `description`, `emailUser`, `datatheme`, `points`, `votes`) VALUES
	(47, 'Sistemas Simples', '    Procesos: No implica una transformación física química de la materia si se puede revertir\r\nTransformación: Si implica una transformación física química de la materia no tiene vuelta atrás Por ej: Tostar un Pan\r\n    ', 'Diegopenisi1@gmail.com', '2017-09-01 09:20:13', 5, 1),
	(48, 'Sistemas Complejos', 'Residuo (Salida Secundaria): se puede reciclar, tiene 2:\r\n1. Reutilización directa->Tomo el residuo y lo uso tal cual esta.\r\n2. Reutilización Indirecta->El residuo Se ingresa al proceso de transformación para formar parte del producto final.\r\nDesecho o desperdicio: Se tiene que descartar.\r\nE2: Entrada secundaria No forma parte del producto final, es por ej: si mi producto son lápices, la entrada secundaria seria la caja de los mismos. \r\nFeed Back: retroalimentación, es el retorno y control  de cada una de las partes del sistema (e,p/salida), \r\nControl: Contraste o comparación entre el ser y el deber ser.\r\n', 'davidhnmunoz@gmail.com', '2017-09-01 09:38:49', 17, 7),
	(49, 'Empresas', ' 1.	Competidores: Aquella otra persona que provee un producto o servicio para satisfacer las mismas necesidades de los clientes.\r\n2.	Competidores Potenciales: Están fuera del mercado, e ingresa cuando vende el primer producto, convirtiéndose en competidor (demanda insatisfecha) (necesidad a través de estudio de mercado).\r\n3.	Producto Sustituto: Cambiar un producto por otro\r\n4.	Proveedores: Es quien entrega el producto en Cantidad y oportunidad “Just In time” Justo en el momento necesario. Ej de lo que hace un proveedor es el  Fraccionamiento-> Lo que brinda un supermercado/estación del servicio.\r\n5.	Compradores: Primer objetivo subsistir, ser rentable. Consume mi servicio y producto. Fiabilidad del cliente que el  mismo vuelva.\r\n6.	Sectores industriales de la oferta en general: Analizar todo el mercado, en general.\r\n7.	Análisis de la demanda y oportunidad de posicionamiento: La diferenciación (P.P.S) ingresar y quedar El producto: Me permite posicionarme. El Precio: Por bajo masificación, alto para segmentar y por último Servicio.\r\nPosicionamiento: Entrar en el mercado, se entra al nicho: porción del mercado al que puedo pertenecer, el nicho puede crecer o abarcar más nichos ’Hacer algo exclusivo’.\r\n', 'davidhnmunoz@gmail.com', '2017-09-01 09:54:12', 1, 1),
	(50, 'Costo', 'Es la erogación, pago o inversión que realiza una empresa para el desarrollo de sus actividades principales: Por ej. Si fabrico goma voy a gastar en comprar caucho. Si pongo y vuelve es costo si no gasto: Por ej Luz->Gastos salida de dinero que no se recupera.', 'davidhnmunoz@gmail.com', '2017-09-01 09:57:35', 0, 0),
	(51, 'Amortización', 'La depreciación de valor del producto en función del tiempo->Vida útil.', 'davidhnmunoz@gmail.com', '2017-09-01 09:58:04', 0, 0),
	(52, 'Ser competitivo', 'Ganar lo mismo en menos tiempo.', 'Diegopenisi1@gmail.com', '2017-09-01 10:13:46', 0, 0),
	(53, 'Costo Producción', 'Lo que me cuesta producir una unidad, es el costo del producto terminado y transferido al depósito (Materia + mano de obra +carga fabril= costo de producción) (Materia+ Mano obra + carga fabril =Especies de costos)', 'davidhnmunoz@gmail.com', '2017-09-01 10:16:57', 3, 1),
	(56, 'sistema aaa', '1234', 'davidhnmunoz@gmail.com', '2017-09-12 21:04:57', 0, 0);
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;


-- Volcando estructura para tabla memorium.users
CREATE TABLE IF NOT EXISTS `users` (
  `emailUser` varchar(100) NOT NULL,
  `nameUser` varchar(100) NOT NULL,
  `passwordUser` varchar(100) NOT NULL,
  `dateUser` datetime DEFAULT NULL,
  PRIMARY KEY (`emailUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla memorium.users: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`emailUser`, `nameUser`, `passwordUser`, `dateUser`) VALUES
	('davidhnmunoz@gmail.com', 'Dmunoz', '1234', '2017-08-31 21:32:08'),
	('Diegopenisi1@gmail.com', 'Dpen', '1234', '2017-08-31 21:32:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
